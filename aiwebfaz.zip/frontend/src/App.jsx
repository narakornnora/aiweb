import React from "react";
import AIChat from "./components/AIChat";

function App() {
  return (
    <div>
      <AIChat />
    </div>
  );
}

export default App;
