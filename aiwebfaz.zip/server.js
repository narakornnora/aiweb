import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
import cors from "cors";
import bodyParser from "body-parser";

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// ✅ Route: AI Chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || message.trim() === "") {
      return res.status(400).json({ error: "Message is required" });
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: message }],
      }),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(500).json({ error: data.error.message });
    }

    res.json({ reply: data.choices[0].message.content });
  } catch (err) {
    console.error("Chat API error:", err);
    res.status(500).json({ error: "Chat API error" });
  }
});

// ✅ Route: Generate Website (จำลองการทำเว็บ)
app.post("/api/generate", (req, res) => {
  const { content } = req.body;
  const html = `
    <html>
      <head><title>Generated Website</title></head>
      <body>
        <h1>${content}</h1>
        <p>นี่คือเว็บไซต์ที่ AI สร้างขึ้น 🚀</p>
      </body>
    </html>
  `;
  res.json({ html });
});

app.listen(port, () => {
  console.log(`🚀 Backend running on http://localhost:${port}`);
});
