Place your Google service account key here as translator.json
