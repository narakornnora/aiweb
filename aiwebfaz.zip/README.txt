﻿# AIWebFAZ – Chat → Build → Preview
- Enter = ส่งข้อความ, Shift+Enter = ขึ้นบรรทัดใหม่
- แนบรูปได้ (ใช้เป็น Hero/Gallery ก่อน)
- ปุ่ม "สร้างเว็บไซต์" → เปิดพรีวิวทันที

## Run
copy .env.example to .env แล้วใส่คีย์ (มี/ไม่มี ก็รันได้)
npm install
npm run dev
เปิด http://localhost:5000
